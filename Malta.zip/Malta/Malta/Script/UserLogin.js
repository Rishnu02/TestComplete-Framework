﻿function User_Login()
{
  
  if(Sys.WaitBrowser().Exists)
    {
      Aliases.browser.close();
    }
 


}
